import{bH as o}from"./vendor-Ds6GxaxC.js";function e(){return o.jsx("h1",{children:"404"})}e.displayName="NoPage";export{e as Component};
//# sourceMappingURL=NoPage-DFRH2LS0.js.map
